let myslq = require("mysql");

let conexion = myslq.createConnection({
    host: "localhost",
    database: "libros", 
    user: "root",
    password: "F@rangel18"
});

conexion.connect(function(err){
    if(err){
        throw err;

    }else{
        console.log("Conexion exitosa");
    }
});

conexion.end();

//Registro de datos*// 

app.post("/registrar", (req, res) => {
    const { nombre, apellidos, correo, contraseña, telefono } = req.body;

    if (!nombre || !apellidos || !correo || !contraseña || !telefono) {
        return res.status(400).json({ error: "Todos los campos son obligatorios" });
    }

    const sql = "INSERT INTO Usuarios (nombre, apellidos, correo, contraseña, telefono) VALUES (?, ?, ?, ?, ?)";
    conexion.query(sql, [nombre, apellidos, correo, contraseña, telefono], (err, result) => {
        if (err) {
            console.error("Error al registrar usuario:", err);
            return res.status(500).json({ error: "Error al registrar el usuario" });
        }
        res.json({ mensaje: "Usuario registrado exitosamente" });
    });
});


const PORT = 3306;
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
