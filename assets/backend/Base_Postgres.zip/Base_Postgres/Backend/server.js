const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const conexion = require("./conexion"); // Importa la conexión desde conexion.js

const app = express();

// Middlewares
app.use(cors());
app.use(bodyParser.json());

// Ruta para registrar usuarios
app.post("/registrar", (req, res) => {
    const { nombre, apellidos, correo, contraseña, telefono } = req.body;

    if (!nombre || !apellidos || !correo || !contraseña || !telefono) {
        return res.status(400).json({ error: "Todos los campos son obligatorios" });
    }

    const sql = "INSERT INTO usuarios (nombre, apellidos, correo, contraseña, telefono) VALUES (?, ?, ?, ?, ?)";
    
    conexion.query(sql, [nombre, apellidos, correo, contraseña, telefono], (err, result) => {
        if (err) {
            console.error("❌ Error al registrar usuario:", err);
            return res.status(500).json({ error: "Error al registrar el usuario" });
        }
        res.json({ mensaje: "✅ Usuario registrado exitosamente" });
    });
});

// Iniciar el servidor en el puerto 5000
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
