// Objeto para manejar el carrito de compras
const carrito = {
    // Función para obtener el carrito del localStorage
    obtenerCarrito: function() {
        return JSON.parse(localStorage.getItem("carrito")) || [];
    },

    // Función para guardar el carrito en el localStorage
    guardarCarrito: function(carrito) {
        localStorage.setItem("carrito", JSON.stringify(carrito));
    },

    // Función para agregar productos al carrito
    agregarAlCarrito: function(id, nombre) {
        let carritoActual = this.obtenerCarrito();
        let producto = carritoActual.find(item => item.id === id);

        if (producto) {
            // Si el producto ya existe, aumentar la cantidad
            producto.cantidad++;
        } else {
            // Si no, agregar el producto al carrito
            carritoActual.push({ id, nombre, cantidad: 1 });
        }

        // Guardar el carrito actualizado en el localStorage
        this.guardarCarrito(carritoActual);
        this.mostrarCarrito();
    },

    // Función para eliminar un producto del carrito
    eliminarDelCarrito: function(id) {
        let carritoActual = this.obtenerCarrito().filter(item => item.id !== id);
        this.guardarCarrito(carritoActual);
        this.mostrarCarrito();
    },

    // Función para vaciar el carrito
    vaciarCarrito: function() {
        localStorage.removeItem("carrito");
        this.mostrarCarrito();
    },

    // Función para mostrar el carrito en la interfaz
    mostrarCarrito: function() {
        let carritoActual = this.obtenerCarrito();
        let carritoHTML = document.getElementById("carrito");
        carritoHTML.innerHTML = "";

        if (carritoActual.length === 0) {
            carritoHTML.innerHTML = "<p>El carrito está vacío</p>";
            return;
        }

        // Mostrar los productos en el carrito
        carritoActual.forEach(producto => {
            let item = document.createElement("div");
            item.innerHTML = `
                <p>${producto.nombre} x ${producto.cantidad}</p>
                <button onclick="carrito.eliminarDelCarrito(${producto.id})">Eliminar</button>
            `;
            carritoHTML.appendChild(item);
        });

        // Crear botón para vaciar el carrito
        let botonVaciar = document.createElement("button");
        botonVaciar.textContent = "Vaciar Carrito";
        botonVaciar.onclick = () => this.vaciarCarrito();
        carritoHTML.appendChild(botonVaciar);
    }
};

// Llamar a la función para mostrar el carrito cuando se carga la página
document.addEventListener("DOMContentLoaded", () => carrito.mostrarCarrito());
